<template>
  <footer>
    <div>
      <a class="footer-item"
         target="_blank"
         href="#">RZ</a>
      <span class="footer-dot">·</span>
      <a class="footer-item"
         target="_blank"
         href="#">Fake指南</a>
      <span class="footer-dot">·</span>
      <a class="footer-item"
         target="_blank"
         href="#">Fake协议</a>
      <span class="footer-dot">·</span>
      <a class="footer-item"
         target="_blank"
         href="#">隐私保护协议</a>
      <br />
    </div>
    <div>
      <a class="footer-item"
         target="_blank"
         href="#">应用</a>
      <span class="footer-dot">·</span>
      <a class="footer-item"
         target="_blank"
         href="#">工作</a>
      <span class="footer-dot">·</span>
      <a class="footer-item"
         target="_blank"
         href="#">申请开通Fake机构号</a>
      <br />
    </div>
    <div>
      <a class="footer-item"
         target="_blank"
         href="#">侵权举报</a>
      <span class="footer-dot">·</span>
      <a class="footer-item"
         target="_blank"
         href="#">网上有害信息举报专区</a>
      <br />
    </div>
    <span>违法和不良信息举报:010-82716601</span>
    <br />
    <a class="footer-item"
       target="_blank"
       href="#">儿童色情信息举报专区</a>
    <br />
    <a class="footer-item"
       target="_blank"
       href="#">电信与服务业务经营许可证</a>
    <br />
    <a class="footer-item"
       target="_blank"
       href="#">网络文化经营许可证</a>
    <br />
    <a class="footer-item"
       target="_blank"
       href="#">联系我们</a>
    <span>© 2020 fakezhihu</span>
  </footer>
</template>

<style>
a {
  text-decoration: none;
  color: black;
  text-align: left;
}
footer {
  display: flex;
  flex-direction: column;
  text-align: left;
  margin-top: 10px;
}
</style>